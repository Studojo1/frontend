chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_LI_COOKIES') {
    Promise.all([
      chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'li_at' }),
      chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' }),
    ]).then(([liAt, jsessionid]) => {
      if (!liAt) {
        sendResponse({ error: 'Not logged in to LinkedIn. Please open linkedin.com and sign in first.' });
        return;
      }
      sendResponse({
        li_at: liAt.value,
        jsessionid: jsessionid ? jsessionid.value.replace(/^"|"$/g, '') : '',
      });
    });
    return true;
  }

  if (msg.type === 'SEND_LI_INVITATION') {
    sendLiInvitation(msg).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  }
});

function randomTrackingId() {
  const bytes = new Uint8Array(16);
  crypto.getRandomValues(bytes);
  return btoa(String.fromCharCode(...bytes))
    .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

async function sendLiInvitation({ profileUrl, profileUrn, note }) {
  // Get CSRF token from cookies (IP-bound but we're on the user's real IP here)
  const [jsessionidCookie, liAtCookie] = await Promise.all([
    chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' }),
    chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'li_at' }),
  ]);

  if (!liAtCookie) return { error: 'Not logged in to LinkedIn' };

  const rawCsrf = jsessionidCookie ? jsessionidCookie.value : '';
  // LinkedIn stores JSESSIONID as "ajax:XXXX" — csrf-token header must strip quotes
  const csrf = rawCsrf.replace(/^"|"$/g, '');

  // Fetch profile page from real browser session to extract authToken
  let authToken = null;
  const slug = (profileUrl || '')
    .replace(/\/$/, '').split('/in/')[1]?.split('/')[0]?.split('?')[0];

  if (slug) {
    try {
      const profileRes = await fetch(`https://www.linkedin.com/in/${slug}/`, {
        credentials: 'include',
        headers: { Accept: 'text/html,application/xhtml+xml' },
      });
      const html = await profileRes.text();
      const match = html.match(/"authToken"\s*:\s*"([^"]{10,})"/);
      if (match) {
        authToken = match[1];
      }
    } catch (e) {
      console.warn('[Studojo] authToken fetch failed:', e.message);
    }
  }

  const inviteeProfile = { profileId: profileUrn };
  if (authToken) inviteeProfile.authToken = authToken;

  const baseHeaders = {
    'Content-Type': 'application/json',
    'Accept': 'application/vnd.linkedin.normalized+json+2.1',
    'csrf-token': csrf,
    'x-restli-protocol-version': '2.0.0',
    'x-restli-method': 'CREATE',
    'x-li-lang': 'en_US',
    'Referer': 'https://www.linkedin.com/mynetwork/',
    'Origin': 'https://www.linkedin.com',
  };

  // Attempt 1: normInvitations
  const normPayload = {
    trackingId: randomTrackingId(),
    message: (note || '').slice(0, 300),
    invitations: [],
    excludeInvitations: [],
    invitee: {
      'com.linkedin.voyager.growth.invitation.InviteeProfile': inviteeProfile,
    },
  };

  try {
    const r1 = await fetch('https://www.linkedin.com/voyager/api/growth/normInvitations', {
      method: 'POST',
      credentials: 'include',
      headers: baseHeaders,
      body: JSON.stringify(normPayload),
    });
    console.log('[Studojo] normInvitations status:', r1.status);
    if (r1.status === 200 || r1.status === 201) {
      return { ok: true, endpoint: 'normInvitations', authToken };
    }
  } catch (e) {
    console.warn('[Studojo] normInvitations failed:', e.message);
  }

  // Attempt 2: relationships/invitations
  const relPayload = {
    trackingId: randomTrackingId(),
    invitations: [],
    excludeInvitations: [],
    invitee: {
      'com.linkedin.voyager.relationships.invitation.InviteeProfile': inviteeProfile,
    },
    message: (note || '').slice(0, 300),
  };

  try {
    const r2 = await fetch('https://www.linkedin.com/voyager/api/relationships/invitations', {
      method: 'POST',
      credentials: 'include',
      headers: baseHeaders,
      body: JSON.stringify(relPayload),
    });
    const body2 = await r2.text();
    console.log('[Studojo] relationships/invitations status:', r2.status, body2.slice(0, 200));
    if (r2.status === 200 || r2.status === 201) {
      return { ok: true, endpoint: 'relationships/invitations', authToken };
    }
    return { ok: false, status: r2.status, body: body2, authToken };
  } catch (e) {
    return { error: e.message };
  }
}
