chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'GET_LI_COOKIES') {
    Promise.all([
      chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'li_at' }),
      chrome.cookies.get({ url: 'https://www.linkedin.com', name: 'JSESSIONID' }),
    ]).then(([liAt, jsessionid]) => {
      if (!liAt) {
        sendResponse({ error: 'Not logged in to LinkedIn. Please open linkedin.com and sign in first.' });
        return;
      }
      sendResponse({
        li_at: liAt.value,
        jsessionid: jsessionid ? jsessionid.value.replace(/^"|"$/g, '') : '',
      });
    });
    return true;
  }

  if (msg.type === 'SEND_LI_INVITATION') {
    sendLiInvitation(msg).then(sendResponse).catch(e => sendResponse({ error: e.message }));
    return true;
  }
});

// Opens a background LinkedIn tab, injects a script that runs same-origin
// (no CORS, real cookies, authToken always in DOM), sends the invitation,
// then closes the tab.
async function sendLiInvitation({ profileUrl, profileUrn, note }) {
  const slug = (profileUrl || '')
    .replace(/\/$/, '').split('/in/')[1]?.split('/')[0]?.split('?')[0];

  if (!slug) return { error: 'Invalid profile URL — could not extract slug', ok: false };

  const tabUrl = `https://www.linkedin.com/in/${slug}/`;
  let tab;

  try {
    tab = await chrome.tabs.create({ url: tabUrl, active: false });

    // Wait for tab to finish loading (max 20s)
    await new Promise((resolve) => {
      const timer = setTimeout(resolve, 20000);
      chrome.tabs.onUpdated.addListener(function listener(tabId, info) {
        if (tabId === tab.id && info.status === 'complete') {
          chrome.tabs.onUpdated.removeListener(listener);
          clearTimeout(timer);
          resolve();
        }
      });
    });

    // Give LinkedIn's JS time to render the page data
    await new Promise(r => setTimeout(r, 2500));

    // Inject and execute inside the LinkedIn tab (same origin — no CORS)
    const results = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: tabSendInvitation,
      args: [profileUrn || null, (note || '').slice(0, 300)],
    });

    await chrome.tabs.remove(tab.id).catch(() => {});
    return results?.[0]?.result ?? { error: 'No result from injected script', ok: false };

  } catch (e) {
    if (tab) await chrome.tabs.remove(tab.id).catch(() => {});
    return { error: e.message, ok: false };
  }
}

// Runs INSIDE the LinkedIn tab. Has same-origin access — no CORS, cookies
// attached automatically, authToken readable from the page's own HTML.
function tabSendInvitation(existingUrn, note) {
  function randomId() {
    const bytes = new Uint8Array(16);
    crypto.getRandomValues(bytes);
    return btoa(String.fromCharCode(...bytes))
      .replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  }

  // Check we're on the profile page (not a login redirect)
  if (window.location.pathname.includes('/login') || window.location.pathname.includes('/authwall')) {
    return Promise.resolve({ error: 'Redirected to login — LinkedIn session may be expired', ok: false });
  }

  const html = document.documentElement.innerHTML;

  // Extract authToken
  let authToken = null;
  const atMatch = html.match(/"authToken"\s*:\s*"([^"]{10,})"/);
  if (atMatch) authToken = atMatch[1];

  // Extract fsd_profile URN if not already resolved
  let resolvedUrn = existingUrn;
  if (!resolvedUrn) {
    const urnMatches = [...html.matchAll(/fsd_profile:([A-Za-z0-9_-]{30,})/g)];
    for (const m of urnMatches) {
      if (m[1] && m[1] !== 'urn') { resolvedUrn = m[1]; break; }
    }
  }

  if (!resolvedUrn) {
    return Promise.resolve({ error: 'Could not resolve profile URN from page', ok: false });
  }

  // Get CSRF from cookie (same-origin, so document.cookie is available)
  const csrfMatch = document.cookie.match(/JSESSIONID="?([^";]+)"?/);
  const csrf = csrfMatch ? csrfMatch[1] : null;
  if (!csrf) {
    return Promise.resolve({ error: 'JSESSIONID not found in cookies', ok: false });
  }

  const inviteeProfile = { profileId: resolvedUrn };
  if (authToken) inviteeProfile.authToken = authToken;

  const headers = {
    'Content-Type': 'application/json',
    'Accept': 'application/vnd.linkedin.normalized+json+2.1',
    'csrf-token': csrf,
    'x-restli-protocol-version': '2.0.0',
    'x-restli-method': 'CREATE',
    'x-li-lang': 'en_US',
    'Referer': window.location.href,
    'Origin': 'https://www.linkedin.com',
  };

  // Attempt 1: normInvitations
  const normPayload = {
    trackingId: randomId(),
    message: note,
    invitations: [],
    excludeInvitations: [],
    invitee: { 'com.linkedin.voyager.growth.invitation.InviteeProfile': inviteeProfile },
  };

  // Attempt 2: relationships/invitations
  const relPayload = {
    trackingId: randomId(),
    invitations: [],
    excludeInvitations: [],
    invitee: { 'com.linkedin.voyager.relationships.invitation.InviteeProfile': inviteeProfile },
    message: note,
  };

  return fetch('/voyager/api/growth/normInvitations', {
    method: 'POST', credentials: 'include', headers, body: JSON.stringify(normPayload),
  })
    .then(async r1 => {
      const b1 = await r1.text();
      console.log('[Studojo] normInvitations:', r1.status, b1.slice(0, 200));
      if (r1.status === 200 || r1.status === 201) {
        return { ok: true, endpoint: 'normInvitations', authToken, resolvedUrn };
      }
      // Try relationships/invitations
      return fetch('/voyager/api/relationships/invitations', {
        method: 'POST', credentials: 'include', headers, body: JSON.stringify(relPayload),
      }).then(async r2 => {
        const b2 = await r2.text();
        console.log('[Studojo] relationships/invitations:', r2.status, b2.slice(0, 200));
        return {
          ok: r2.status === 200 || r2.status === 201,
          status: r2.status,
          body: b2,
          normStatus: r1.status,
          normBody: b1,
          authToken,
          resolvedUrn,
        };
      });
    })
    .catch(e => ({ error: e.message, ok: false, resolvedUrn }));
}
