// Listen for requests from the Studojo page
window.addEventListener('STUDOJO_REQUEST_LI_COOKIES', () => {
  chrome.runtime.sendMessage({ type: 'GET_LI_COOKIES' }, (response) => {
    if (chrome.runtime.lastError) {
      window.dispatchEvent(new CustomEvent('STUDOJO_LI_COOKIES', {
        detail: { error: 'Extension error: ' + chrome.runtime.lastError.message },
      }));
      return;
    }
    window.dispatchEvent(new CustomEvent('STUDOJO_LI_COOKIES', { detail: response }));
  });
});

// Relay invitation send requests to the background service worker
// Background worker fetches the LinkedIn profile page from the real browser session
// to extract authToken, then POSTs the invitation — no proxy needed.
window.addEventListener('STUDOJO_SEND_INVITATION', (e) => {
  chrome.runtime.sendMessage({ type: 'SEND_LI_INVITATION', ...e.detail }, (response) => {
    if (chrome.runtime.lastError) {
      window.dispatchEvent(new CustomEvent('STUDOJO_INVITATION_RESULT', {
        detail: { error: 'Extension error: ' + chrome.runtime.lastError.message },
      }));
      return;
    }
    window.dispatchEvent(new CustomEvent('STUDOJO_INVITATION_RESULT', { detail: response }));
  });
});

// Signal to the page that the extension is installed (fires on initial load)
window.dispatchEvent(new CustomEvent('STUDOJO_EXT_READY'));

// Also respond to pings — handles the case where the page mounted after this script ran
window.addEventListener('STUDOJO_PING', () => {
  window.dispatchEvent(new CustomEvent('STUDOJO_EXT_READY'));
});
